import pygame
from pygame.locals import *
import time
pygame.init()


class PlayerBullets():
     
    def __init__(self, x, y, pb_img):
      self.img = pb_img
      self.x = x
      self.y = y
      self.ychange = -13
      self.c_time = time.time()
      self.delay_time = 0.5