import pygame
import random
import time
import sys
from pygame.locals import *
from pygame import mixer

import classes 

BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)

w = 600
h = 1280

pygame.init()

#display
screen = pygame.display.set_mode((w, h))
screenrect = screen.get_rect()

backgroundImg = pygame.image.load('space-background.png')
background = pygame.transform.scale(backgroundImg, (730, 1370))

mixer.music.load('background.wav')
mixer.music.play(-1)

#player
heartImg = []
emptyHeartImg = []
num_of_hearts = 3

spaceShipImg = pygame.image.load('player.png')
playerImg = pygame.transform.scale(spaceShipImg, (130, 130))

player_health = 500
player_hearts = 3

heart = pygame.image.load('heart.png')
empty_heart = pygame.image.load('empty-heart.png')
for i in range(num_of_hearts):
  heartImg.append(pygame.transform.scale(heart, (60, 60)))
  emptyHeartImg.append(pygame.transform.scale(empty_heart, (60, 60)))


player_rect = playerImg.get_rect()
player_rect.center = (screenrect.w / 2, screenrect.h / 1.1)

#enemy
#spaceInvaderImg = []
enemyImg = []
enemyX = []
enemyY = []
enemyX_change = []
enemyY_change = []
enemy_health = []
display_health = []
enemy_rect = []

num_of_enemies = 5

for i in range(num_of_enemies):
  #spaceInvaderImg.append()
  spaceInvaderImg = pygame.image.load('ufo.png')
  
  enemyImg.append(pygame.transform.scale(spaceInvaderImg, (90, 90)))

  enemyX.append((random.randint(0, 597)))
  #enemyY.append(0)
  enemyY.append((random.randint(15, 400)))

  enemyX_change.append(9) #9
  enemyY_change.append(30) #20
  
  enemy_health.append(100)
  display_health.append(100)
  
  enemy_rect.append(enemyImg[i])
 
Bullets = [] 
Fire = False
pg_img = pygame.transform.scale(pygame.image.load("bullet2E2.png"), (60, 60))   

class PlayerBullet:
    def __init__(self, x, y):
      self.img1 = pygame.transform.scale(pygame.image.load("bullet2E2.png"), (60, 60))
      self.img2 = pygame.transform.scale(pygame.image.load("bullet2E2.png"), (60, 60))
      self.x = x
      self.y = y
      self.ychange = -16
      
      self.rect1 = pygame.Rect((x , y), (14, 40))
      self.rect1.x = x + 4
      self.rect1.y = y
      
      self.rect2 = pygame.Rect((x , y), (14, 40))
      self.rect2.x = x + 112
      self.rect2.y = y 
      
      self.c_time = time.time()
      self.delay_time = 1

#bullet
specialBulletImg = pygame.image.load('bullet.png')
special_bullet = pygame.transform.scale(specialBulletImg, (60, 60))
special_bulletX = 0
special_bulletY = player_rect.y

special_bulletX_change = 0
special_bulletY_change = 20 #20

special_bullet_state = "ready"
special_fire = False


font = pygame.font.Font('freesansbold.ttf', 32)
font2 = pygame.font.Font('freesansbold.ttf', 75)

score_value = 0

time_limit = 2
time_state = "ready"
start_time = time.time()

def player(x, y):
  screen.blit(playerImg, (x, y))

def enemy(x, y, i):
  screen.blit(enemyImg[i], (x, y))
  
def fire_bullet(x, y):
  global special_bullet_state
  special_bullet_state = "fire"
  screen.blit(special_bullet, (x + 40, y))

def isCollisionBullet(bullet_rect1, bullet_rect2, enemy_rect, enemy_health_par, i):
  global enemy_health
  if(bullet_rect1.colliderect(enemy_rect) and not(Bullet[-1].y == player_rect.y)):
    enemy_health[i] -= 50
    return True
  else:
    return False

def isCollisionSpecialBullet(bullet_rect, enemy_rect, enemy_health_par, i):
  global enemy_health
  if(bullet_rect.colliderect(enemy_rect) and not(special_bulletY == player_rect.y)):
    enemy_health[i] -= 50
    return True
  else:
    return False

def isCollisionPlayer(player_rect, enemy_health, i):
  global player_health
  if player_rect.colliderect(enemy_rect[i]):
    player_health -= 100
    return True
  else:
    return False
    

def run_time(elapsed, start):
  global time_state
  time_state = "fire"
    

hit = 0
fire_time = False    
running = True
touched = False
gameOver = False
collide = False
bul_time = .5


clock = pygame.time.Clock()
while running:
    
    screen.fill(BLACK)
    
    screen.blit(background, (0, 0))
    
    clock.tick(30)
    
    elapsed_time = time.time()
    elapsed_time = int(elapsed_time)
    
    for event in pygame.event.get():
        if(event.type == QUIT or(event.type == KEYDOWN and(event.key == pygame.K_ESCAPE))):
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
           if player_rect.collidepoint(event.pos):
               if special_fire == False:
                 special_bulletX = playerX
               Fire = True
               touched = True
           if special_fire == False:
             special_bullet_sound = mixer.Sound('laser.wav')
             special_bullet_sound.play()
             special_bulletX = playerX
             special_fire = True
           
        elif event.type == pygame.MOUSEBUTTONUP:
            touched = False
            Fire = False
        
        elif(event.type == MOUSEMOTION and(touched)):
          player_rect.move_ip(event.rel)
          
    playerX = player_rect.x
    playerY = player_rect.y
        
    if playerX <= 0:
      playerX = 0
      player_rect.x = 0
    elif playerX >= 597:
      playerX = 597
      player_rect.x = 597
    
    if playerY <= 800:
      playerY = 800
      player_rect.y = 800
    elif playerY >= 1250:
      playerY = 1250
      player_rect.y = 1250
    
    for i in range(num_of_enemies):
      
      if enemyY[i] > 1353:
        gameOver = True
      
      if gameOver:
        for j in range(num_of_enemies):
          enemyY[j] = 2000    
        game_over_txt = font2.render("GaMe ØvEr", True, (204, 78, 33))
        screen.blit(game_over_txt, (150, 550))
      
      enemyX[i] += enemyX_change[i]
    
      if enemyX[i] <= 0:
        enemyX_change[i] = 9
        enemyY[i] += enemyY_change[i]
      elif enemyX[i] >= 597:
        enemyX_change[i] = -9
        enemyY[i] += enemyY_change[i]
      
      special_bullet_rect = pygame.Rect((special_bulletX + 58, special_bulletY + 25), (13, 30)) 
      enemy_rect[i] = pygame.Rect((enemyX[i] + 22, enemyY[i] + 35), (85, 60))
      
      
      special_bullet_collision = isCollisionSpecialBullet(special_bullet_rect, enemy_rect[i], enemy_health, i)
      if special_bullet_collision:
        explosion_sound = mixer.Sound('explosion.wav')
        explosion_sound.play()
        #fire_bullet(bulletX, bulletY)
        #bulletY -= bulletY_change
        special_bulletY = player_rect.y
        fire_time = True
        collide = True
        
      if enemy_health[i] <= 0:
        score_value += 1
        enemy_health[i] = 100
          
        enemyX[i] = random.randint(0, 597)
        enemyY[i] = random.randint(15, 150)
          
          
      player_collision = isCollisionPlayer(player_rect, enemy_rect[i], i)
      if player_collision:
        explosion_sound = mixer.Sound('explosion.wav')
        explosion_sound.play()
        
        enemyX[i] = random.randint(0, 597)
        enemyY[i] = random.randint(15, 150)
        
        if(player_health == 0 and not(player_hearts == 0)):
          player_health = 500
          player_hearts -= 1
        if player_hearts <= 0:
          gameOver = True
        
      
        
      #pygame.draw.rect(screen, (255, 0, 0), enemy_rect[i], 2)
      
      enemy(enemyX[i], enemyY[i], i)
     
      render = font.render(f"{enemy_health[i]}", True, BLACK)
      if enemy_health[i] >= 100 and collide:
        screen.blit(render, (enemyX[i] + 34, enemyY[i] + 50))
      elif enemy_health[i] <= 99:
        screen.blit(render, (enemyX[i] + 44, enemyY[i] + 50))
      
        
    #pygame.draw.rect(screen, WHITE, player_rect, 2)
    
    screen.blit(heartImg[0], (500, 15))
    screen.blit(heartImg[1], (565, 15))
    screen.blit(heartImg[2], (630, 15))
    
    if player_hearts == 2:
      heartImg[0] = emptyHeartImg[0]
    elif player_hearts == 1:
      heartImg[1] = emptyHeartImg[1]
    elif player_hearts == 0:
      heartImg[2] = emptyHeartImg[2]
    
    if Fire:
      if not len(Bullets):
        Bullets.append(PlayerBullet(playerX, playerY))
    
      elif(time.time() - Bullets[-1].c_time) >= Bullets[-1].delay_time:
        Bullets.append(PlayerBullet(playerX, playerY))  
   
    
                                                           
    for j,i in enumerate(Bullets):
        screen.blit(i.img1, (i.x - 19, i.y))
        screen.blit(i.img2, (i.x + 89, i.y ))
        i.y += i.ychange
        i.rect1.y = i.y + 30
        i.rect2.y = i.y + 30
        
        #pygame.draw.rect(screen, YELLOW, i.rect1, 2)
        #pygame.draw.rect(screen, YELLOW, i.rect2, 2)
        
        for k in range(num_of_enemies):
          if i.rect1.colliderect(enemy_rect[k]) or i.rect2.colliderect(enemy_rect[k]):
            explosion_sound = mixer.Sound('explosion.wav')
            explosion_sound.play()
            
            enemy_health[k] -= 10
            
            Bullets.pop(j)
            
            #enemyX[k] = random.randint(0, 597)
            #enemyY[k] = random.randint(15, 150)
        if i.y <= 0 and len(Bullets):
          Bullets.pop(j)  
        
      
    if special_fire and not collide:
      fire_bullet(special_bulletX, special_bulletY)
    
    if special_bullet_state is "fire" and not collide:
      elapsed_time = time.time() - start_time
      elapsed_time = int(elapsed_time)
      fire_bullet(special_bulletX, special_bulletY)
      special_bulletY -= special_bulletY_change
    
    if fire_time:
      run_time(elapsed_time, start_time)
    if time_state is "fire":
      elapsed_time = elapsed_time - start_time
      elapsed_time = int(elapsed_time)
      
    if(int(elapsed_time) >= time_limit):
       special_bulletY = player_rect.y
       special_bullet_state = "ready"
       special_fire = False
       
       collide = False
       
       fire_time = False
       time_state = "ready"
       start_time = time.time()
    
    score = font.render(f"score: {score_value}", True, (0, 255, 0))
    screen.blit(score, (10, 10)) 
    
    player(playerX, playerY)
    pygame.display.update()
    
text2 = font.render("Bye", True, (255, 255, 255))
screen.blit(text2, (0, 0))