import pygame as pg
from pygame.locals import *
import sys
import random
import time
import os
from os import path

WIDTH = 800
HEIGHT = 2000
FPS = 60

WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BULE = (0, 0, 255)
BLACK = (0, 0, 0)
DARKGREEN = (0, 100, 0)
YELLOW = (255, 255, 0)

img_dir = path.join(path.dirname(__file__), 'Images')
aud_dir = path.join(path.dirname(__file__), 'Audios')

pg.init()
pg.mixer.init()
screen = pg.display.set_mode((WIDTH, HEIGHT))
screen_rect = screen.get_rect()
clock = pg.time.Clock()

def newMob():
  m = Mob()
  all_sprites.add(m)
  mobs.add(m)

def draw_health_bar(surf, x, y, pct, color1, color2):
  if pct < 0:
    pct = 0
    
  BAR_WIDTH = 250
  BAR_HEIGHT = 30
  
  fill = (pct / 100) * BAR_WIDTH
  outline_rect = pg.Rect(x, y, BAR_WIDTH, BAR_HEIGHT)
  fill_rect = pg.Rect(x, y, fill, BAR_HEIGHT)
  if player.health <= 25:
    hp = font.render(f"HP", True, RED)
  elif player.health <= 50:
    hp = font.render(f"HP", True, YELLOW)
  else:
    hp = font.render(f"HP", True, DARKGREEN)
    
  pg.draw.rect(surf, color1, fill_rect)
  pg.draw.rect(surf, color2, outline_rect, 2)
  screen.blit(hp, (BAR_WIDTH / 2.25 , 48))
 
def toss():
    return random.randint(0,2)
       
class Player(pg.sprite.Sprite):
  def __init__(self):
    pg.sprite.Sprite.__init__(self) 
    self.image = pg.transform.scale(player_img, (100, 100))
    self.image.set_colorkey(BLACK)
    self.rect = self.image.get_rect()
    self.rect.center = (screen_rect.w / 2, screen_rect.h / 1.1)
    self.speedX = 0
    self.touched = False
    self.radius = 35
    self.c_time = 0
    self.delay_time = 0.5
    self.health = 100
    
  def update(self):
    if self.rect.x <= 0:
      self.rect.x = + 10
    elif self.rect.x >= WIDTH + 20:
      self.rect.x = WIDTH + 10
    
    if self.rect.y >= HEIGHT - 5:
        self.rect.y = HEIGHT
    elif self.rect.y <= 350:
        self.toss = toss()
        if self.toss == 1:
            self.rect.y += 10
            self.toss = toss()
            if toss == 1:
                self.rect.x += 10
            elif toss == 2:
                self.rect.x -= 10
  
  def shoot(self):
    self.c_time = time.time()
    bullet = Bullet(self.rect.centerx, self.rect.top)
    all_sprites.add(bullet)
    bullets.add(bullet)
    random.choice(shoot_sounds).play()

class Mob(pg.sprite.Sprite):
  def __init__(self):
    pg.sprite.Sprite.__init__(self)
    self.image_orig = random.choice(meteor_images)
    self.image_orig.set_colorkey(BLACK)
    self.image = self.image_orig.copy()
    self.rect = self.image.get_rect()
    self.radius = int(self.rect.width * .85 / 2)
    self.rect.x = random.randrange(WIDTH - self.rect.width)
    self.rect.y = random.randrange(-100, -70)
    self.speedX = random.randrange(-3, 3)
    self.speedY = random.randrange(1, 9)
    self.rot = 0
    self.rot_speed = random.randint(-8, 8)
    self.last_update = pg.time.get_ticks()
  
  def rotate(self):
    now = pg.time.get_ticks()
    if now - self.last_update > 50:
      self.last_update = now
      self.rot = (self.rot + self.rot_speed) % 360
      new_image = pg.transform.rotate(self.image_orig, self.rot)
      old_center = self.rect.center
      self.image = new_image 
      self.rect = self.image.get_rect()
      self.rect.center = old_center
       
  def update(self):
    self.rotate()
    self.rect.x += self.speedX
    self.rect.y += self.speedY
    if self.rect.top > HEIGHT + 100 or self.rect.left < -70 or self.rect.right > WIDTH + 200:
      self.image_orig = random.choice(meteor_images)
      self.image_orig.set_colorkey(BLACK)
      self.rect.x = random.randrange(WIDTH - self.rect.width)
      self.rect.y = random.randrange(-100, -70)
      self.speesX = random.randrange(-3, 3)
      self.speedY = random.randrange(1, 8)
      
num_of_mobs = random.randint(6, 8) 

class Bullet(pg.sprite.Sprite):
  def __init__(self, x, y):
    pg.sprite.Sprite.__init__(self)
    self.image = pg.transform.scale(bullet_img, (20, 75))
    self.image.set_colorkey(BLACK)
    self.rect = pg.Rect((x, y), (20, 60))
    self.rect.centerx = x - 7
    self.rect.bottom = y
    self.speedY = -10
    
  def update(self):
    self.rect.y += self.speedY
    if self.rect.bottom < 0:
       self.kill()
       
Fire = False 

class Explosion(pg.sprite.Sprite):
  def __init__(self, center, size):
    pg.sprite.Sprite.__init__(self)      
    self.size = size
    self.image = explosion_anim[size][0]
    self.rect = self.image.get_rect()
    self.rect.center = center
    self.frame = 0
    self.last_update = pg.time.get_ticks()
    self.frame_rate = 100
  
  def update(self):
    now = pg.time.get_ticks()
    if now - self.last_update > self.frame_rate:
      last_update = now
      self.frame += 1
      if self.frame == len(explosion_anim[self.size]):
        self.kill()
      else:
        #self.frame += 1
        center = self.rect.center
        self.image = explosion_anim[self.size][self.frame]
        self.rect = self.image.get_rect()
        self.rect.center = center  

background_img = pg.image.load(path.join(img_dir, 'background3.png')).convert()
background = pg.transform.scale(background_img, (1080, 3000))
background_rect = background.get_rect()
player_img = pg.image.load(path.join(img_dir, 'playerShip1_orange.png')).convert()
bullet_img = pg.image.load(path.join(img_dir, 'laserRed16.png')).convert()
meteor_images = []
meteor_list = ['meteorBrown_big1.png', 'meteorBrown_big2.png', 'meteorBrown_big3.png',
               'meteorBrown_big4.png', 'meteorBrown_med1.png', 'meteorBrown_med2.png',
               'meteorBrown_small1.png', 'meteorBrown_small2.png', 'meteorBrown_tiny1.png',
               'meteorBrown_tiny2.png']

for img in meteor_list:
  meteor_images.append(pg.image.load(path.join(img_dir, img)).convert())                                                                                                                                                                                                                                                                 

explosion_anim = {}
explosion_anim['lg'] = []
explosion_anim['sm'] = []
explosion_anim['player'] = []

for i in range(23):
  filename = 'expl_01_00{}.png'.format(i)
  img = pg.image.load(path.join(img_dir, filename)).convert()
  img.set_colorkey(BLACK)
  imglg = pg.transform.scale(img, (80*10, 80*10))
  imgsm = pg.transform.scale(img, (35, 35))
  explosion_anim['lg'].append(imglg)
  explosion_anim['sm'].append(imgsm)

for j in range(31):
  filename = 'expl_06_00{}.png'.format(j)
  img = pg.image.load(path.join(img_dir, filename)).convert()
  img.set_colorkey(BLACK)
  imgplayer = pg.transform.scale(img, (80, 80))
  explosion_anim['player'].append(imgplayer)
  
shoot_sounds = []
shoot_sound_list = ['laser1A.mp3', 'laser1A2.mp3', 'laser1B.mp3', 'laser1C2.mp3']
for aud in shoot_sound_list:
  shoot_sounds.append(pg.mixer.Sound(path.join(aud_dir, aud)))

pg.mixer.music.load(path.join(aud_dir, 'background-music.ogg'))
pg.mixer.music.set_volume(0.6)

all_sprites = pg.sprite.Group()
mobs = pg.sprite.Group()
bullets = pg.sprite.Group()
player = Player()
all_sprites.add(player)

for i in range(num_of_mobs):
  newMob()
  #m = Mob()
  #all_sprites.add(m)
  #mobs.add(m)
  
meteor_destroyed = 0
hits = 0
score = 0
font = pg.font.Font('freesansbold.ttf', 32)

Width = 1090
Height = 3000

pg.mixer.music.play(loops=-1)

running = True
while running:
  for event in pg.event.get():
    if(event.type == QUIT or(event.type == KEYDOWN and(event.key == pg.K_ESCAPE))):
      running = False
    elif event.type == MOUSEBUTTONDOWN:
      if player.rect.collidepoint(event.pos):
        player.touched = True
        Fire = True
    elif event.type == MOUSEBUTTONUP:
      player.touched = False
      Fire = False
    elif event.type == MOUSEMOTION and player.touched:
      player.rect.move_ip(event.rel)
    
  if Fire:
    if time.time() - player.c_time > player.delay_time: 
      player.shoot()
    
  clock.tick(FPS)
  
  all_sprites.update()
  hit1 = pg.sprite.groupcollide(mobs, bullets, True, True, pg.sprite.collide_circle)
  for hit in hit1:
    #m = Mob()
    #all_sprites.add(m)
    #mobs.add(m)
    expl = Explosion(hit.rect.center, 'lg')
    all_sprites.add(expl)
    newMob()
    
    score += 50 - hit.radius
    meteor_destroyed += 1
    if meteor_destroyed % 30 == 0 and not meteor_destroyed == 1:
      num_of_mobs += 1
  hit2 = pg.sprite.spritecollide(player, mobs, True, pg.sprite.collide_circle)
  for hit in hit2:
    #m = Mob()
    #all_sprites.add(m)
    #mobs.add(m)
    expl = Explosion(hit.rect.center, 'sm')
    all_sprites.add(expl)
    newMob()
    player.health -= hit.radius * 1.25
    if player.health <= 0:
      running = False
  
  screen.fill(BLACK)
  screen.blit(background, background_rect)
  all_sprites.draw(screen)
 
  draw_health_bar(screen, 7, 45, player.health, GREEN, WHITE)
  
  text_score = font.render(f"{score}", True, WHITE)
  screen.blit(text_score, (10 , 5))
  
  #pg.draw.circle(screen, RED, m.rect.center, m.radius)
  #pg.draw.rect(screen, RED, m.rect, 2)
  
  #pg.draw.circle(screen, GREEN, player.rect.center, player.radius)
  #pg.draw.rect(screen, GREEN, player.rect, 2)
  
  #pg.draw.rect(screen, YELLOW, bull.rect, 2)
  
  #360 685
  
  pg.display.flip()
  
pg.quit()
sys.exit()