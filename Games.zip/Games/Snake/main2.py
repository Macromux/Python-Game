import sys
from classes import *
#import pygame
pg.init()
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption("FlappyBird")
clock = pg.time.Clock()
font = pg.font.Font("freesansbold.ttf", 32)

block = SCREEN_WIDTH // 18

snake = Snake(black, block, block, block, 1, 250, screen)
#food = Food(red, block, screen)
score = 0
snake_list = []
snake_length = 1
while True:
	keys = pg.key.get_pressed()
	for event in  pg.event.get():
	    if event.type == pg.QUIT:
	        EXIT_GAME = False
	    if event.type == pg.KEYDOWN:
	    	key = event.key
	    	if key == K_UP:
	    		snake.v_y = 0
	    		snake.v_y -= snake.speed
	    		snake.v_x = 0
	    	if key == K_DOWN:
	    		snake.v_y = 0
	    		snake.v_y += snake.speed
	    		snake.v_x = 0
	    	if key == K_LEFT:
	    		snake.v_x = 0
	    		snake.v_x -= snake.speed
	    		snake.v_y = 0
	    	if key == K_RIGHT:
	    		snake.v_x = 0
	    		snake.v_x += snake.speed
	    		snake.v_y = 0
	 
	snake.update()
	clock.tick(60)
	'''if abs(snake.rect.x - food.x) < block and abs(snake.rect.y - food.y) < block:
		food = Food(red, block, screen)
		snake.time -= 10
		if snake.time < 0:
			snake.speed += 1
		score += 1
		snake_length += 5'''
	
	screen.fill(white)
	draw_grid(SCREEN_WIDTH, 22, screen)
	head = []
	head.append(snake.rect.x)
	head.append(snake.rect.y)
	snake_list.append(head)
	snake.draw(snake_list)
	#food.draw()
	screen.blit((font.render(f"{score}", True, black)), (0, 0))
	pygame.display.update()

pygame.quit()
sys.exit()

        