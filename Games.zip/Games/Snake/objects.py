from pygame.locals import *
import pygame as pg
import random
from setting import *
white = (255, 255, 255)
red = (255, 0, 0)
black = (0, 0, 0)

SCREEN_WIDTH = 900
SCREEN_HEIGHT = 1380
FPS = 60

class Snake(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE, TILESIZE))
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y

    def move(self, dx=0, dy=0):
        self.x += dx
        self.y += dy

    def update(self):
        self.rect.x = self.x * TILESIZE
        self.rect.y = self.y * TILESIZE

class player(pg.sprite.Sprite):
	def __init__(self, colour, x, y, block, speed, time, surface):
		self.groups = game.all_sprites
		pg.sprite.Sprite.__init__(self, self.groups)
		self.game = game
		self.colour = colour
		self.v_x = 0
		self.v_y = 0
		self.rect = pg.Rect((x, y), (block, block))
		self.image = pg.Surface((TILE))
		self.size = block
		self.time = time
		self.speed = speed
		self.surface = surface
	def update(self):
		self.rect.x += self.v_x
		self.rect.y += self.v_y
		if self.v_x > 0:
			while self.rect.x % self.size != 0:
				self.rect.x += 1
		elif self.v_x < 0:
			while self.rect.x % self.size != 0:
				self.rect.x -= 1
		else:
			self.v_x = 0
			
		if self.v_y > 0:
			while self.rect.y % self.size != 0:
				self.rect.y += 1
		elif self.v_y < 0:
			while self.rect.y % self.size != 0:
				self.rect.y -= 1
		else:
			self.v_y = 0
	def draw(self, snake_list):
		pg.time.delay(self.time)
		for x,y in snake_list:
			pg.draw.rect(self.surface, self.colour, [x, y, self.size, self.size])
		
class Food():
	def __init__(self, colour, block, surface):
		self.x = 1
		self.y = 1
		while self.x % block != 0:
			self.x = random.randint(0, 672)
			if self.x == 1:
				self.x = 0
		while self.y % block != 0:
			self.y = random.randint(0, 672)
			if self.y == 1:
				self.y = 0
			
		self.colour = colour
		self.size = block
		self.surface = surface
	def draw(self):
		pg.draw.rect(self.surface, self.colour, [self.x, self.y, self.size, self.size])
		
def draw_grid(surface):
	size = w // r
	x = 0
	y = 0
	for _ in range(r):
		x += size
		y += size
		pg.draw.line(surface, black, (x, 0), (x, w*1.22))
		pg.draw.line(surface, black, (0, y), (w, y))
		