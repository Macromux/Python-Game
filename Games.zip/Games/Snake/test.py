import pygame
import random
pygame.init()

SCREEN_WIDTH = 720
SCREEN_HEIGHT = 1380
FPS = 60

white = (255, 255, 255)
red = (255, 0, 0)
black = (0, 0, 0)

win = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Test")
clock = pygame.time.Clock()
font = pygame.font.Font("freesansbold.ttf", 32)

block = SCREEN_WIDTH // 15
food_x = 1
food_y = 1

#food_x = random.randint(0, 1)
while food_x % block != 0:
	text = font.render(f"{block%food_x}", True, black)
	food_x = random.randint(0, 672)
	if food_x == 1:
		food_x = 0
while food_y % block != 0:
	#text = font.render(f"{}", True, black)
	food_y = random.randint(0, 672)
text = font.render(f"{food_x}", True, black)
 
def draw_grid(w, r, surface):
	size = w // 15
	x = 0
	y = 0
	for _ in range(r):
		x += size
		y += size
		pygame.draw.line(surface, black, (x, 0), (x, w))
		pygame.draw.line(surface, black, (0, y), (w, y))
		
RUNNING = True
while RUNNING:
	for event in pygame.event.get():
		if event == pygame.QUIT:
			RUNNING = False
		
		win.fill(white)
		draw_grid(SCREEN_WIDTH, 15, win)
		pygame.draw.rect(win, red, [food_x, food_y, block, block])
		win.blit(text, (0, 0))
		pygame.display.update()
		
pygame.quit()
		