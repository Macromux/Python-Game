import turtle as Tur
import time

wn = Tur.Screen()
wn.title("pong by jnity studios")
wn.bgcolor("black")
wn.tracer(0)

score_a = 0
score_b = 0

hits = 6
speed = 0
ori = 1.5

incre = 0
lose = False

paddle_a = Tur.Turtle()
paddle_a.speed(0)
paddle_a.shape("square")
paddle_a.color("white", "#154223")
paddle_a.shapesize(stretch_wid=9, stretch_len=1.2)
paddle_a.penup()
paddle_a.goto(-525, 0)

paddle_b = Tur.Turtle()
paddle_b.speed(0)
paddle_b.shape("square")
paddle_b.color("white", "#783d06")
paddle_b.shapesize(stretch_wid=9, stretch_len=-1.2)
paddle_b.penup()
paddle_b.goto(525, 0)

score = Tur.Turtle()
score.speed(0)
score.color("orange", "white")
score.penup()
score.hideturtle()
score.goto(0, 230)
score.write("Player_A: 0 Palyer_B: 0", align="center", font=("Courier", 10, "normal"))

ball = Tur.Turtle()
ball.speed(speed)
ball.shape("square")
ball.color("orange", "#db8a1f")
ball.penup()
ball.goto(0, 0)
ball.dx = ori
ball.dy = ori

def move_a(x, y):
	x = -525
	paddle_a.goto(x, y)

def move_b(x, y):
	x = 525
	paddle_b.goto(x, y)

paddle_a.ondrag(move_a)
paddle_b.ondrag(move_b)

while True:
	
	wn.update()
	ball.setx(ball.xcor() + ball.dx)
	ball.sety(ball.ycor() + ball.dy)
	
	
	if ball.xcor() > 625:
		ball.goto(0, 0)
		ball.dx *= -1
		hits = 6
		speed = 0
		score_a += 1
		score.clear()
		score.write(f"Player_A: {score_a} Palyer_B: {score_b}", align="center", font=("Courier", 10, "normal"))
		time.sleep(1)
		lose = True
		
	if ball.xcor() < -625:
		ball.goto(0, 0)
		ball.dx *= -1
		hits = 6
		speed = 0
		score_b += 1
		score.clear()
		score.write(f"Player_A: {score_a} Palyer_B: {score_b}", align="center", font=("Courier", 10, "normal"))
		time.sleep(1)
		lose = True
			
	
	if ball.xcor() > 525 and ball.xcor() < 535 and(ball.ycor() < paddle_b.ycor() + 10 and ball.ycor() > paddle_b.ycor() - 10):
		ball.setx(525)
		ball.dx *= -1
		hits += 1
	
	if ball.xcor() < -525 and ball.xcor() > -535 and(ball.ycor() < paddle_a.ycor() + 10 and ball.ycor() > paddle_a.ycor() - 10):
		ball.setx(-525)
		ball.dx *= -1
		hits += 1
    
	if hits >= 31 and lose == True:
	   	hits = 6
	   	ori = 1.5
	   	speed = 0
	   	incre += 0.1
	   	ori + incre
	   	speed + incre
		
	if hits % 5 == 0:	
		hits += 1
		ori += 0.1
		speed += 0.1
		ball.dx = ori
		ball.dy = ori
		ball.speed(speed)  
		
	if ball.ycor() > 290:
		ball.sety(290)
		ball.dy *= -1
		
	if ball.ycor() < -290:
		ball.sety(-290)
		ball.dy *= -1
		
		
