import random
import sys
import pygame
from pygame.locals import *


pygame.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 1280
FPS = 60

WHITE = (255, 255, 255)

SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("FlappyBird")

RUN =  True
while RUN:
    
    for event in  pygame.event.get():
        if event.type == pygame.QUIT:
            RUN = False
        elif event.type == pygame.KEYDOWN:
        	pass
pygame.quit()
sys.exit()
    